from math import trunc

n = float(input("Digite um valor numérico: "))
print("Porção inteira do número {}: {:.0f}".format(n, trunc(n)))
