from datetime import date

ano = int(input("Ano de nascimento: "))
atual = date.today().year
idade = 2022 - ano
print("Quem nasceu em {} tem {} em {}.".format(ano, idade, atual))
if idade < 18:
    print("Você deverá se alistar daqui a {} anos.".format(18 - idade))
    print("Seu alistamento será em {}.".format(18 - idade + atual))
elif idade == 18:
    print("Você deverá se alistar este ano!")
else:
    print("Você já deveria ter se alistado há {} anos atrás.".format((18 - idade) * -1))
    print("Seu alistamento foi em {}.".format(18 - idade + atual))
