s = float(input("Leitor de salário: R$"))
aumento = 15 / 100 * s
print("Salário original: R${:.2f}.\nSalário com 15% de aumento: R${:.2f}.".format(s, s + aumento))
