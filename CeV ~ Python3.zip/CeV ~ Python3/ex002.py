nome = str(input("Digite seu nome: "))
print("É um prazer te conhecer, {:=^20}!".format(nome))
