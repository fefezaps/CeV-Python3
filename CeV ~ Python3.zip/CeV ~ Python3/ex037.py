n = int(input("Digite um número inteiro: "))
code = int(input("[ 1 ] Código Binário\n[ 2 ] Código Octal\n[ 3 ] Código Hexadecimal\nEscolha um tipo de código: "))
if code == 1:
    print("Código Binário: {}".format(bin(n).replace("0b", "")))
elif code == 2:
    print("Código Octal: {}".format(oct(n).replace("0o", "")))
elif code == 3:
    print("Código Hexadecimal: {}".format(hex(n).replace("0x", "")))
else:
    print("{}Digite um número da lista! >:({}".format("\033[1;31m", "\033[m"))
