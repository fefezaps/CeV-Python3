import math

n = float(input("Digite um ângulo: "))
sin = math.sin(math.radians(n))
cos = math.cos(math.radians(n))
tan = math.tan(math.radians(n))
print("Seno: {:.2f}\nCosseno: {:.2f}\nTangente: {:.2f}".format(sin, cos, tan))
