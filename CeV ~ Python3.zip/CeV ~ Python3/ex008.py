m = float(input("Digite um valor em metros²: "))
cm = m * 100
mm = m * 1000
print("Conversão feita!")
print("Centímetros: {:.2f}\nMilímetros: {:.2f}".format(cm, mm))
