aluno = str(input("Nome do aluno: "))
n1 = float(input("Primeira nota: "))
n2 = float(input("Segunda nota: "))
n3 = float(input("Terceira nota: "))
media = (n1 + n2 + n3) / 3
print("{} | Média: {:.2f}".format(aluno, media))
