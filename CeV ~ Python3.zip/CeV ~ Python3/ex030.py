n = int(input("Digite um número inteiro: "))
if n % 2 == 0:
    print("Número par.")
else:
    print("Número ímpar.")
