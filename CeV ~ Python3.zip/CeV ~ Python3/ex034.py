salario = float(input("Salário: "))
if salario > 1250:
    aumento = 10 / 100 * salario
    print("Maior.\nSeu salário será de: {}".format(salario + aumento))
else:
    aumento = 15 / 100 * salario
    print("Menor.\nSeu salário será de: {}".format(salario + aumento))
