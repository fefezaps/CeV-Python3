n1 = int(input("Digite um número inteiro: "))
n2 = int(input("Digite um segundo número inteiro: "))
if n1 > n2:
    print("O maior valor é {}".format(n1))
elif n2 > n1:
    print("O maior valor é {}".format(n2))
else:
    print("Não existe um valor maior, os dois ({} e {}) são iguais.".format(n1, n2))
