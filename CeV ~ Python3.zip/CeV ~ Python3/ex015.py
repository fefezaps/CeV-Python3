d = int(input("Dias alugado: "))
km = float(input("Km² rodados: "))
preco = (d * 60) + (km * 0.15)
print("O total a pagar será de: R${:.2f}".format(preco))
