ano = int(input("Ano: "))
if ano % 4 == 0:
    print("É ano bissexto.")
else:
    print("Não é ano bissexto.")
