nome = str(input("Nome completo: "))
nome1 = nome.split()
print("Primeiro nome: {}".format(nome1[0]))
print("Último nome: {}".format(nome1[len(nome1)-1]))
