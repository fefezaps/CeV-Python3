n1 = float(input("Primeira nota: "))
n2 = float(input("Segunda nota: "))
n3 = float(input("Terceira nota: "))
media = (n1 + n2 + n3) / 3
if media < 6:
    print("REPROVADO, sua média é {:.2f}!".format(media))
elif 6 <= media < 7:
    print("RECUPERAÇÃO, sua média é {:.2f}!".format(media))
else:
    print("APROVADO, sua média é {:.2f}!".format(media))
