la = float(input("Largura da parede em metros²: "))
al = float(input("Altura da parede em metros²: "))
a = la * al
tinta = a / 2
print("A parede possui {}m².\nSerá necessário comprar {} litros de tinta.".format(a, tinta))
