cidade = str(input("Cidade: ")).upper().strip()
pcidade = cidade.split()
print("{}".format("SANTO" in pcidade[0]))
