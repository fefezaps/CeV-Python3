import math

n = int(input("Digite um valor numérico inteiro: "))
db = n * 2
tp = n * 3
raiz = math.sqrt(n)
print("Dobro: {}\nTriplo: {}\nRaiz quadrada: {:.0f}".format(db, tp, raiz))
