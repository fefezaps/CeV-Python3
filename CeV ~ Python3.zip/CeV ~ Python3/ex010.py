n = float(input("Quanto dinheiro há na carteira?: "))
dol = n / 3.27
print("Você poderá trocar R${:.2f} por ${:.2f}.".format(n, dol))
