nome = str(input("Nome: ")).lower()
print("{}".format("silva" in nome))
