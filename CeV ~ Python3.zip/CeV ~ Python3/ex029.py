km = int(input("Km²/h: "))
if km > 80:
    multa = (km - 80) * 7
    print("Multado! Valor: R$ {:.2f}".format(multa))
else:
    print("Sem multas!")
print("Dirija com segurança!")
