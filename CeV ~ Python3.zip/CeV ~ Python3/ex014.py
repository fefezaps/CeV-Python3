c = float(input("Temperatura em °C: "))
f = (c * 9/5) + 32
print("Graus Celsius: {}°C\nGraus Fahrenheit: {}°F".format(c, f))
