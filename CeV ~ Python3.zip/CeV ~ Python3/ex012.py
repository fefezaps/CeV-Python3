p = float(input("Leitura de preço de produtos: R$"))
desc = 5 / 100 * p
print("Preço original: R${:.2f}.\nPreço com desconto (5%): R${:.2f}.".format(p, p - desc))
