frase = str(input("Digite uma frase: ")).lower().strip()
print("A letra 'A' aparece {} veze(s).".format(frase.count("a")))
print("A primeira letra 'A' aparece na posição {}.".format(frase.find("a") + 1))
print("A última letra 'A' aparece na posição {}.".format(frase.rfind("a") + 1))
