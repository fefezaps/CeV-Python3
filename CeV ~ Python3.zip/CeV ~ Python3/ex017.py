import math
cato = float(input("Primeiro cateto: "))
cata = float(input("Segundo cateto: "))
hipo = math.hypot(cato, cata)
print("A hipotenusa deste triângulo retângulo vale: {}".format(hipo))
