import playsound

playsound.playsound('caramelldansen.mp3')
