casa = float(input("Valor da casa: R$"))
salario = float(input("Salário do comprador: R$"))
anos = int(input("Em quantos anos será pago: "))
prestacao = casa / (anos * 12)
minimo = salario * 30 / 100
print("Para pagar uma casa de R${:.2f} em {} anos\nA prestação será de R${;.2f}.".format(casa, anos, prestacao))
if prestacao > minimo:
    print("Perdão, mas você não pode financiar esta casa! :(")
else:
    print("O valor de cada prestação ficará por R${:.2f}.".format(prestacao))
