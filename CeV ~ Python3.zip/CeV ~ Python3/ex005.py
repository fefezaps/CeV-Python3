n = int(input("Digite um valor numérico inteiro: "))
suc = n + 1
ant = n - 1
print("Sucessor: {}\nAntecessor: {}".format(suc, ant))
