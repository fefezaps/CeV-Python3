n1 = int(input("Digite um número: "))
n2 = int(input("Digite outro número: "))
s = n1 + n2
m = n1 * n2
d = n1 / n2
di = n1 // n2
e = n1 ** n2
print("A soma dos dois números é {}\nO produto é {}\nE a divisão resulta em {:.3f}.".format(s, m, d))
print("A divisão inteira resulta em {}\nE a exponenciação resulta em {}.".format(di, e))
