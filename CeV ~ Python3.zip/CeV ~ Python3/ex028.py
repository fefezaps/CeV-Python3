import random

print("Pensei em um número! Consegue adivinhar?")
n = int(input("Digite um número: "))
pensei = random.randint(0, 5)
if n == pensei:
    print("Você acertou! Na mosca!!")
    print("Pensei no {}!".format(pensei))
else:
    print("Errado! Talvez na próxima :(")
    print("Pensei no {}!".format(pensei))
