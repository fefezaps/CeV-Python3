km = int(input("Km² da viagem: "))
if km < 200:
    passagem = 0.50
    print("0,50 a passagem.\nO valor da passagem ficará por: R${:.2f}".format(passagem * km))
else:
    passagem = 0.45
    print("0,45 a passagem.\nO valor da passagem ficará por: R${:.2f}".format(passagem * km))
